
package impuestos;


public class Impuestos extends Calculos{
private int marca,modelo,pago,servicio,traslado,linea;
private double valorF,a;
private int b;
    public int getMarca() {
        return marca;
    }

    public void setMarca(int marca) {
        this.marca = marca;
    }

    public int getLinea() {
        return linea;
    }

    public void setLinea(int linea) {
        this.linea = linea;
    }

    public int getModelo() {
        return modelo;
    }

    public void setModelo(int modelo) {
        this.modelo = modelo;
    }

    public int getPago() {
        return pago;
    }

    public void setPago(int pago) {
        this.pago = pago;
    }

    public int getServicio() {
        return servicio;
    }

    public void setServicio(int servicio) {
        this.servicio = servicio;
    }

    public int getTraslado() {
        return traslado;
    }

    public void setTraslado(int traslado) {
        this.traslado = traslado;
    }

    public double getValorF() {
        return valorF;
    }

    public void setValorF(double valorF) {
        this.valorF = valorF;
    }

    public double getA() {
        return a;
    }

    public void setA(double a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }
    

    public Impuestos(int marca, int linea, int modelo, int pago, int servicio, int traslado) {
        this.marca = marca;
        this.linea = linea;
        this.modelo = modelo;
        this.pago = pago;
        this.servicio = servicio;
        this.traslado = traslado;
    }

    public Impuestos() {
    }
    
    
    
@Override
    public String cuesta(){
    if (marca==0){
      if(linea==0){
        if(modelo==0){
            b = 30000000;
            return "el valor de su carro es: "+ b;
        }   
        if(modelo==1){
            b = 25500000;
            return "el valor de su carro es: "+ b;
        }
        if(modelo==2){
            b = 30000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==3){
            b = 40000000;
             return "el valor de su carro es: "+ b;
        }
      }
      if(linea==1){ 
        if(modelo==0){
            b = 36000000;
             return "el valor de su carro es: "+ b;
        }   
        if(modelo==1){
            b = 30500000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==2){
            b = 50000000;
            return "el valor de su carro es: "+ b;
        }
        if(modelo==3){
            b = 55000000;
             return "el valor de su carro es: "+ b;
        }
      }
      if(linea==2){
        if(modelo==0){
            b = 45500000;
             return "el valor de su carro es: "+ b;
        }   
        if(modelo==1){
            b = 45000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==2){
            b = 45500000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==3){
            b = 45550000;
             return "el valor de su carro es: "+ b;
        }
      }
    }
    if (marca==1){
      if(linea==0){
        if(modelo==0){
            b = 50500000;
             return "el valor de su carro es: "+ b;
        }   
        if(modelo==1){
            b = 50000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==2){
             b = 50600000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==3){
             b = 35550000;
             return "el valor de su carro es: "+ b;
        }
      }
      if(linea==1){ 
        if(modelo==0){
            b = 45550000;
             return "el valor de su carro es: "+ b;
        }   
        if(modelo==1){
             b = 45000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==2){
             b = 40000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==3){
             b = 43000000;
             return "el valor de su carro es: "+ b;
        }
      }
      if(linea==2){
        if(modelo==0){
           b = 44000000;
             return "el valor de su carro es: "+ b;
        }   
        if(modelo==1){
            b = 45000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==2){
            b = 44000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==3){
            b = 43000000;
             return "el valor de su carro es: "+ b;
        }
      }
    }
    if (marca==2){
      if(linea==0){
        if(modelo==0){
            b = 50000000;
             return "el valor de su carro es: "+ b;
        }   
        if(modelo==1){
            b = 49000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==2){
            b = 48000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==3){
            b = 48500000;
             return "el valor de su carro es: "+ b;
        }
      }
      if(linea==1){ 
        if(modelo==0){
            b = 43000000;
             return "el valor de su carro es: "+ b;
        }   
        if(modelo==1){
            b = 44000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==2){
           b = 45000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==3){
            b = 45500000;
             return "el valor de su carro es: "+ b;
        }
      }
      if(linea==2){
        if(modelo==0){
            b = 39000000;
             return "el valor de su carro es: "+ b;
        }   
        if(modelo==1){
           b = 40000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==2){
            b = 42000000;
             return "el valor de su carro es: "+ b;
        }
        if(modelo==3){
            b = 41000000;
             return "el valor de su carro es: "+ b;
        }
      }
    }
    return "";
    }
    
@Override
    public String impues(){
     
     if (b<50000000){
      a=((b*1.5)/100); return "\n"+"el impuesto cuesta     "+a;
     }
     if ((50000000<=b)&&(b<100000000)){
         a=((b*2.5)/100); return "\n"+"el impuesto cuesta     "+a;
     }
     if(b>100000000){
        a=((b*3.5)/100); return "\n"+"el impuesto cuesta     "+a;
     }
     else{
       return"";
     }
 
    }
    
@Override
    public String descuentos(){
        int DServicio;
        double DPago,DTraslado;
        DServicio=150000;
        DPago=(10*a)/100;
        DTraslado=(15*a)/100;
        
    if((pago==0)&&(servicio==0)&&(traslado==0)){
        valorF=a-DPago-DServicio-DTraslado;
        return "\n"+"el descuento por servicio publico es  "+DServicio+"\n"+"(10%)descuento Pago  "+DPago+"\n"+"(15%)descuento traslado  "+DTraslado;
    }if((pago==0)&&(servicio==0)){
        valorF=a-DPago-DServicio;
        return "\n"+"el descuento por servicio publico es "+DServicio+"\n"+"(10%)descuento Pago  "+DPago;
    }if((servicio==0)&&(traslado==0)){
        valorF=a-DServicio-DTraslado;
        return "\n"+"el descuento por servicio publico es "+DServicio+"\n"+"(15%)descuento traslado  "+DTraslado;
    }if((pago==0)&&(traslado==0)){
        valorF=a-DPago-DTraslado;
        return "\n"+"(10%)descuento Pago "+DPago+"\n"+"(15%)descuento traslado "+DTraslado;
    }if((pago==0)){
        valorF=a-DPago;
        return "\n"+"(10%)descuento Pago  "+DPago;
    }if((servicio==0)){
        valorF=a-DServicio;
        return "\n"+"el descuento por servicio publico es "+DServicio;
    }if((traslado==0)){
        valorF=a-DTraslado;
        return "\n"+"(15%)descuento traslado "+DTraslado;
    }else{
        valorF=a;
        return "\n"+"no tiene ningun descuento";
      }
    }
    
@Override
    public String imprime(){  
    return "\n"+"el valor final a pagar es "+valorF;
    }

    
}
