/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impuestos;

/**
 *
 * @author Nicol PC
 */
public abstract class Calculos {
   public abstract String cuesta();
   public abstract String impues();
   public abstract String descuentos();
   public abstract String imprime();
}
